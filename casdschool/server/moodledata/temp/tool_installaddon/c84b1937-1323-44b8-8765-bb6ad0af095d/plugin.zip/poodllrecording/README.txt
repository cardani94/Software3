PoodLL Recording
========================================
Thanks for downloading PoodLL.

Installation instructions and a video can be found at http://www.poodll.com .

There should be only one folder "poodllrecording" in the poodllrecording folder after you unzip the zip file.
Place this folder into your moodle installation under the [site_root]/question/type folder.

Then login to your site as admin and go to your Moodle site's top page. Moodle should then guide you through the installation or upgrade of the PoodLL filter. 

Then when you go to create a question you should see a new question type, poodllrecording, in the list. 

*Please be aware that the PoodLL Recording question relies on the PoodLL Filter being installed, and won't work properly otherwise*

Good luck.

Justin Hunt
